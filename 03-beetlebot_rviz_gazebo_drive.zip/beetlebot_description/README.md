# beetlebot_description

ROS 2 URDF description package for BeetleBot mobile robot.

## Package Structure

```
beetlebot_description/
├── CMakeLists.txt
├── package.xml
├── README.md
├── urdf/
│   └── beetlebot.urdf.xacro    # Main robot description
├── meshes/                      # STL files from SolidWorks
│   ├── base_link.STL
│   ├── fl_link.STL
│   ├── bl_link.STL
│   ├── br_link.STL
│   ├── fr_link.STL
│   ├── lidar_link.STL
│   ├── camera_link.STL
│   └── imu_link.STL
├── launch/
│   ├── display.launch.py       # RViz visualization
├── rviz/
│   └── view_robot.rviz         # RViz configuration
└── config/                      # (empty, for future params)
```

## Installation

1. **Copy this package to your workspace:**
   ```bash
   cd ~/beetlebot_ws/src/
   cp -r /path/to/beetlebot_description .
   ```

2. **Copy your STL files:**
   ```bash
   cp /path/to/your/meshes/*.STL ~/beetlebot_ws/src/beetlebot_description/meshes/
   ```

3. **Build:**
   ```bash
   cd ~/beetlebot_ws
   colcon build --packages-select beetlebot_description
   source install/setup.bash
   ```

## Usage

### View in RViz (No Simulation)

```bash
ros2 launch beetlebot_description display.launch.py
```

This opens RViz with the robot model. Use the joint sliders to move wheels.

```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard
```

## Topics Published (Simulation Only)

- `/scan` - LiDAR (sensor_msgs/LaserScan)
- `/camera/image_raw` - Camera (sensor_msgs/Image)
- `/imu/data_raw` - IMU (sensor_msgs/Imu)
- `/odom` - Odometry (nav_msgs/Odometry)
- `/joint_states` - Wheel positions (sensor_msgs/JointState)

## Frame Structure (REP-105 Compliant)

```
base_footprint  (on ground)
    └── base_link  (elevated by wheel radius = 0.065m)
            ├── fl_link  (front left wheel)
            ├── bl_link  (back left wheel)
            ├── br_link  (back right wheel)
            ├── fr_link  (front right wheel)
            ├── base_laser_link  (LiDAR)
            ├── base_camera_link  (Camera)
            │       └── camera_optical_link
            └── base_imu_link  (IMU)
```

## Key Fix from SolidWorks Export

**Problem:** SolidWorks exports `base_link` at ground level, causing robot to sink.

**Solution:** Added `base_footprint` frame and elevated `base_link` by wheel radius (0.065m).

```xml
<joint name="base_footprint_joint" type="fixed">
  <parent link="base_footprint"/>
  <child  link="base_link"/>
  <origin xyz="0 0 0.065" rpy="0 0 0"/>  <!-- Lifts robot up -->
</joint>
```

Now wheels touch ground correctly!

## Parameters

From URDF xacro properties:
- `wheel_radius`: 0.065 m
- `wheel_width`: 0.04 m  
- `track_width`: 0.287 m (left to right wheel separation)
- `base_mass`: 1.874 kg
- `wheel_mass`: 0.160 kg each

## Troubleshooting

### Robot sinks into ground
✓ **FIXED** - This xacro has proper base_footprint offset

### Meshes not loading
```bash
# Check file names match exactly:
ls ~/beetlebot_ws/src/beetlebot_description/meshes/
# Should see: base_link.STL, fl_link.STL, etc.
```

### "Package beetlebot_description not found"
```bash
source ~/beetlebot_ws/install/setup.bash
```

## Next Steps

This package follows the **Beetlebot Architecture Document** Section 3:
- Package: `beetlebot_description` ✓
- Correct frame naming (`base_*` prefix) ✓
- Works with RViz and Gazebo ✓

Next packages to create:
- `beetlebot_interfaces` - Custom messages
- `beetlebot_base` - Lyra communication
- `beetlebot_localization` - Odometry
- `beetlebot_navigation` - Nav2 integration

## License

BSD
