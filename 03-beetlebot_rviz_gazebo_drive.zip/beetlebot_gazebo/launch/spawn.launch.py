import os
import xacro

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import SetEnvironmentVariable, DeclareLaunchArgument
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.actions import IncludeLaunchDescription
from launch.actions import TimerAction
from launch.substitutions import LaunchConfiguration

def generate_launch_description():

    # Paths
    description_pkg = get_package_share_directory("beetlebot_description")
    gazebo_pkg = get_package_share_directory("beetlebot_gazebo")

    xacro_file = os.path.join(
        description_pkg, "urdf", "beetlebot.urdf.xacro"
    )

    world_file = os.path.join(
        gazebo_pkg, "worlds", "empty.sdf"
    )

    # Process URDF
    doc = xacro.process_file(xacro_file)
    robot_description = doc.toxml()

    # Gazebo resource path (for meshes)
    gazebo_resource_path = SetEnvironmentVariable(
        name="GZ_SIM_RESOURCE_PATH",
        value=os.pathsep.join([
            os.path.dirname(description_pkg),
            os.path.dirname(gazebo_pkg)
        ])
    )

    # Use the standard Gazebo launch that includes clock bridge
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory("ros_gz_sim"),
                "launch",
                "gz_sim.launch.py",
            )
        ),
        launch_arguments={
            "gz_args": f"-r {world_file}",
            "on_exit_shutdown": "true"
        }.items(),
    )

    # Bridge for clock - EXPLICIT
    gz_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
        ],
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    # Robot State Publisher
    robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[{
            "robot_description": robot_description,
            "use_sim_time": True
        }],
        output="screen"
    )

    # Spawn robot in Gazebo
    spawn_robot = Node(
        package="ros_gz_sim",
        executable="create",
        arguments=[
            "-name", "beetlebot",
            "-topic", "robot_description",
            "-x", "0.0",
            "-y", "0.0",
            "-z", "0.07",
        ],
        parameters=[{'use_sim_time': True}],
        output="screen"
    )

    # Spawn controllers
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "joint_state_broadcaster",
            "--controller-manager",
            "/controller_manager"
        ],
        parameters=[{'use_sim_time': True}],
        output="screen",
    )

    diff_drive_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=[
            "diff_drive_controller",
            "--controller-manager",
            "/controller_manager"
        ],
        parameters=[{'use_sim_time': True}],
        output="screen",
    )

    cmd_vel_relay = Node(
        package="beetlebot_safety",
        executable="cmd_vel_relay",
        name="cmd_vel_relay",
        parameters=[{'use_sim_time': True}],
        output="screen",
    )

    return LaunchDescription([
        gazebo_resource_path,
        gazebo,
        gz_bridge,
        robot_state_publisher,
        
        TimerAction(period=3.0, actions=[spawn_robot]),
        TimerAction(period=6.0, actions=[joint_state_broadcaster_spawner]),
        TimerAction(period=7.0, actions=[diff_drive_controller_spawner]),
        TimerAction(period=8.0, actions=[cmd_vel_relay]),  # ← This line
    ])
