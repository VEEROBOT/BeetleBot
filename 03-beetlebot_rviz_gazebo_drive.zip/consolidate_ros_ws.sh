#!/usr/bin/env bash
set -euo pipefail
IFS=$'\n\t'

SUFFIX=$(date +"%H%M")
OUTPUT_FILE="CONSOLIDATED_ROS_${SUFFIX}.txt"

EXCLUDES="build|install|devel|.git|.vscode|log"

rm -f "$OUTPUT_FILE"

append_file () {
  local file="$1"
  file "$file" | grep -q text || return
  {
    echo
    echo "######################################################################"
    echo "# --- FILE: $file ---"
    echo "######################################################################"
    cat "$file"
  } >> "$OUTPUT_FILE"
}

find . \( -regex ".*/\(${EXCLUDES}\)/.*" \) -prune -o -type f -print |
sort |
while read -r f; do
  case "$f" in
    */package.xml|*/CMakeLists.txt|*.launch|*.xacro|*.launch.py|*.py|*.yaml|*.cfg|*.rviz|*.urdf|*.sdf|*.md|*.sh|*.txt|*.xml)
      append_file "$f"
      ;;
  esac
done
