#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist, TwistStamped

class CmdVelRelay(Node):
    def __init__(self):
        super().__init__('cmd_vel_relay')
        self.subscription = self.create_subscription(Twist, '/cmd_vel', self.callback, 10)
        self.publisher = self.create_publisher(TwistStamped, '/diff_drive_controller/cmd_vel', 10)
        self.get_logger().info('Safety relay: /cmd_vel -> /diff_drive_controller/cmd_vel')
    
    def callback(self, msg):
        out = TwistStamped()
        out.header.stamp = self.get_clock().now().to_msg()
        out.header.frame_id = 'base_footprint'
        out.twist = msg
        self.publisher.publish(out)

def main(args=None):
    rclpy.init(args=args)
    rclpy.spin(CmdVelRelay())

if __name__ == '__main__':
    main()
