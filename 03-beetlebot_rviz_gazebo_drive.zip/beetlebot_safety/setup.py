from setuptools import find_packages, setup

package_name = 'beetlebot_safety'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Praveen',
    maintainer_email='praveen@eltorq.com',
    description='Safety and command arbitration for Beetlebot',
    license='BSD',
    entry_points={
        'console_scripts': [
            'cmd_vel_relay = beetlebot_safety.cmd_vel_relay:main',
        ],
    },
)
